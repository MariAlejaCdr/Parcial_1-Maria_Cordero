package Datos;
/** @author Alejandra**/

public class cls_Inventario {
    private String Codigo;
    private String Nombre;
    private String Cantidad;
    private String Descripcion;
    private String Categoria;

    public cls_Inventario(String Codigo, String Nombre, String Cantidad, String Descripcion, String Categoria) {
        this.Codigo = Codigo;
        this.Nombre = Nombre;
        this.Cantidad = Cantidad;
        this.Descripcion = Descripcion;
        this.Categoria = Categoria;
    }

    //Getters
    public String getCodigo() {
        return Codigo;
    }
    public String getNombre() {
        return Nombre;
    }
    public String getCantidad() {
        return Cantidad;
    }
    public String getDescripcion() {
        return Descripcion;
    }
    public String getCategoria() {
        return Categoria;
    }

    //Setters
    public void setCodigo(String Codigo) {
        this.Codigo = Codigo;
    }
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    public void setCantidad(String Cantidad) {
        this.Cantidad = Cantidad;
    }
    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }
    public void setCategoria(String Categoria) {
        this.Categoria = Categoria;
    }
}